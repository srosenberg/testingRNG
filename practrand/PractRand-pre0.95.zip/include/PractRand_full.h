#ifndef _PractRand_full_h
#define _PractRand_full_h

#include "PractRand/config.h"
#include "PractRand/rng_basics.h"
#include "PractRand/rng_helpers.h"
#include "PractRand/test_helpers.h"
#include "PractRand/test_batteries.h"
//#include "PractRand/rng_adaptors.h"
#include "PractRand/tests.h"
#include "PractRand/test_batteries.h"

#endif //_PractRand_full_h
